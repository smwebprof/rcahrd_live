


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Self Assessment Form</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">SelfForm</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Employee Self Evaluation & Assessment Form</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="quickForm">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Your thorough and timely participation in the appraisal process will help facilitate a fair and comprehensive review of
your progress and accomplishments since your last performance review. If you have been employed by the company
less than a year, substitute references to "since the last review" with "since you were hired" and answer the questions
accordingly.</label>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">1. List your most significant accomplishments or contributions in the last year. How do these achievements align with
the goals/objectives outlined in your last review?</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">2. With reference to your current job description, kindly list the top three responsibilities that are part of your day to
day activity</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">3. Since the last appraisal period, have you successfully performed any new tasks or additional duties outside the
scope of your regular responsibilities? If so, please specify.
</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">4. What activities have you initiated, or actively participated in to encourage teamwork within your group and/or
office?
</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">5. Describe the areas you feel require improvement in terms of your professional capabilities. List the steps you plan
to take and/or the resources you need to accomplish this.
</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">6. Have you received adequate training or is there any specific training that you feel you could benefit from and needs
to be undertaken?
</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">7. Identify two career goals for the coming year and indicate how you plan to accomplish them
</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">8. Evaluate yourself on all factors that apply to you since your last performance appraisal OR date of hire if employed
for less than one year. If a category does not apply to you, indicate N/A. 
</label>

                  </div>

                  <div class="card">
              <div class="card-header">
                <h3 class="card-title">Striped Full Width Table</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Task</th>
                      <th>Progress</th>
                      <th style="width: 40px">Label</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1.</td>
                      <td>Update software</td>
                      <td>
                        <div class="progress progress-xs">
                          <div class="progress-bar progress-bar-danger" style="width: 55%"></div>
                        </div>
                      </td>
                      <td><span class="badge bg-danger">55%</span></td>
                    </tr>
                    <tr>
                      <td>2.</td>
                      <td>Clean database</td>
                      <td>
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-warning" style="width: 70%"></div>
                        </div>
                      </td>
                      <td><span class="badge bg-warning">70%</span></td>
                    </tr>
                    <tr>
                      <td>3.</td>
                      <td>Cron job running</td>
                      <td>
                        <div class="progress progress-xs progress-striped active">
                          <div class="progress-bar bg-primary" style="width: 30%"></div>
                        </div>
                      </td>
                      <td><span class="badge bg-primary">30%</span></td>
                    </tr>
                    <tr>
                      <td>4.</td>
                      <td>Fix and squish bugs</td>
                      <td>
                        <div class="progress progress-xs progress-striped active">
                          <div class="progress-bar bg-success" style="width: 90%"></div>
                        </div>
                      </td>
                      <td><span class="badge bg-success">90%</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
                  
                  <div class="form-group">
                    <label for="exampleInputEmail1">9. Name any other management personnel, besides your current supervisor, that you feel should provide input toward
your performance appraisal. Also any other management personnel whom you feel should provide you guidance /
knowledge regarding your scope of work/ improvement in your career growth?

</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">10. Basis your observations since your date of joining, is there any specific area that you wish to highlight / want
changes in your department / your work / anything that you are not satisfied with? 

</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">11. Please to rate your immediate supervisor on the same scale as mentioned in the questionnaire above – in terms of
professional support given to the team, personal development and guidance, general approach to your team and
work
</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">12. Do you require additional support / guidance from your immediate supervisor? Please use this space to add any
other comments you wish to. 
</label>
                    <textarea class="form-control" rows="3" name="client_address" id="client_address"></textarea>
                  </div>
                  <div class="form-group mb-0">
                    Thank you for taking the time to complete the Employee Self Evaluation & Assessment Form!
                  </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Partial Save</button>
                  <button type="submit" class="btn btn-default">Cancel</button>
                  <button type="submit" class="btn btn-secondary">Final Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  