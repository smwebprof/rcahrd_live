<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_master extends CI_Model{ 

    function getRows($params){ 

        $querystring = "SELECT * FROM emp_master WHERE emp_id = '".$params['emp_code']."' and permanent_password = '".$params['password']."' and is_active = 1";
        $queryforpubid = $this->db->query($querystring);

        $result = $queryforpubid->result_array();
        return $result;

    }

    function getRowsEmail($params){ 

        $querystring = "SELECT * FROM emp_master WHERE email_address = '".$params['emp_code']."' and permanent_password = '".$params['password']."' and is_active = 1";
        $queryforpubid = $this->db->query($querystring);

        $result = $queryforpubid->result_array();
        return $result;

    }

    function getRowsByEmpCode($params){ 

        $querystring = "SELECT * FROM emp_master WHERE emp_id = '".$params."'";
        $queryforpubid = $this->db->query($querystring);

        $result = $queryforpubid->result_array();
        return $result;

    }

    function getRowsByEmpEmail($params){ 

        $querystring = "SELECT * FROM emp_master WHERE email_address = '".$params."'";
        $queryforpubid = $this->db->query($querystring);

        $result = $queryforpubid->result_array();
        return $result;

    }

    public function updateUserPass($data){
        //print_r($data);exit;
        $result = array('permanent_password'=>$data['password'],'password_change_flag'=>'Y');
        //print_r($result);exit;
        $this->db->where('emp_id', $data['emp_code']);
        $this->db->update('emp_master',$result);
        //echo $this->db->last_query();exit;
        return (($this->db->affected_rows() > 0)?TRUE:FALSE);


   }

   public function updateUserPassEmail($data){
        //print_r($data);exit;
        $result = array('permanent_password'=>$data['password'],'password_change_flag'=>'Y');
        //print_r($result);exit;
        $this->db->where('email_address', $data['emp_code']);
        $this->db->update('emp_master',$result);
        //echo $this->db->last_query();exit;
        return (($this->db->affected_rows() > 0)?TRUE:FALSE);


   }

   function getEmpDetails($params){ 

        $querystring = "SELECT em.id,em.emp_first_name,em.emp_last_name,em.emp_id,rsa.id rsa_id,rsa.status,rsa.entrydate,em.add_self_form FROM emp_master em left join response_self_assesment rsa ON em.id = rsa.empid WHERE em.id = '".$params."'";
        $queryforpubid = $this->db->query($querystring);

        $result = $queryforpubid->result_array();
        return $result;

    }

    function getFullEmpDetails($params){ 

        $querystring = "SELECT em.emp_first_name,em.emp_last_name,em.emp_id,em.joining_date,bm.branch_name,dp.department_name,dm.designation_name,emp.emp_first_name fname,emp.emp_last_name lname,em.add_self_form FROM emp_master em left join designation_master dm ON em.designation_master_id = dm.id left join department_master dp ON em.department_id = dp.id left join branch_master bm ON em.branch_id = bm.id left join emp_master emp ON emp.id = em.reporting_emp_id WHERE em.id = '".$params."'";
        $queryforpubid = $this->db->query($querystring);

        $result = $queryforpubid->result_array();
        return $result;

    }

    function getEmpReportDetails(){ 

        $querystring = "SELECT em.id,em.emp_first_name,em.emp_last_name,em.emp_id,rsa.id rsa_id,rsa.status,rsa.entrydate,emp.emp_first_name fname,emp.emp_last_name lname FROM response_self_assesment rsa left join emp_master em ON em.id = rsa.empid left join emp_master emp ON emp.id = em.reporting_emp_id";
        $queryforpubid = $this->db->query($querystring);

        $result = $queryforpubid->result_array();
        return $result;

    }

    function getLoginYr(){ 

        $querystring = "SELECT * FROM rca_operation_year WHERE is_active = '1'";
        $queryforpubid = $this->db->query($querystring);

        $result = $queryforpubid->result_array();
        return $result;

    }

    public function Updateselfformstatus($data){

      $result = array('add_self_form'=>'Y'); 
      
      //print_r($result);exit;
      $this->db->where('id', $data);
      $this->db->limit(1);
      $this->db->update('emp_master',$result);
      //echo $this->db->last_query();exit;
      return (($this->db->affected_rows() > 0)?TRUE:FALSE);

   }

    
    
}
