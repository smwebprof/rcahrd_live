<?php $this->load->view('admin/layout/header_selfreports'); ?>
<?php $this->load->view('admin/layout/menu'); ?>	
<?php 
	  $this->load->view($layout_body); 
?>

<?php $this->load->view('admin/layout/footer_selfreports'); ?>

