<?php $this->load->view('admin/layout/header_app'); ?>
<?php $this->load->view('admin/layout/menu'); ?>	
<?php 
	  $this->load->view($layout_body); 
?>

<?php $this->load->view('admin/layout/footer_app'); ?>

