<?php $this->load->view('admin/layout/header_app_form1'); ?>
<?php $this->load->view('admin/layout/menu'); ?>	
<?php 
	  $this->load->view($layout_body); 
?>

<?php $this->load->view('admin/layout/footer_app_form1'); ?>

