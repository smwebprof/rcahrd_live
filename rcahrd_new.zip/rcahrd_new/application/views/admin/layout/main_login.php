<?php $this->load->view('admin/layout/header_login'); ?>
<?php //echo $this->load->view('admin/layout/menu'); ?>	
<?php 
	  $this->load->view($layout_body); 
?>

<?php $this->load->view('admin/layout/footer_login'); ?>

